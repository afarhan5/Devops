# Linux_30
- I am Learner of Batch Vidhyarthi-30
- It contains total 8 Assignments, on Linux and Git topics (with Readme.md file of each assignment)

